#include <graphics/texture.h>
#include <cstddef> // for NULL definition

namespace gef
{
	Texture* Texture::Create(const Platform& platform, const ImageData& image_data)
	{
		return NULL;
	}
}