#include <graphics/index_buffer.h>
#include <cstddef> // for NULL definition

namespace gef
{
	IndexBuffer* IndexBuffer::Create(Platform& platform)
	{
		return NULL;
	}
}